<?php $__env->startPush('css'); ?>
<script src="https://cdn.tiny.cloud/1/0fzrtif8pxlg6kw3rfi13s2t5xzfaiqpavx3fiqci9ysvmva/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>

<style>
    .makescroll {
        border:2px solid #ccc;
         width:300px; height: 100px;
          overflow-y: scroll!important;
    }

    label {
        margin-left: 20px;
    }
    #datepicker {
        width:180px; margin: 0 20px 20px 20px;
    }
    #datepicker > span:hover{
        cursor: pointer;
    }
</style>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
    <div class="card">
        <div class="card-header bg-dark text-white text-bold">
            Tambah Berita 
            <a class="btn btn-danger btn-sm float-right" href="<?php echo e(route('daftar-artikel')); ?>" role="button">Kembali</a>
        </div>
        <div class="card-body">
            <div class="container">
                <form action="<?php echo e(route('post-tambah-artikel')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-8 col-sm-8 col-md-8">
                            <div class="card">
                                <div class="card-body">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-12 col-sm-12 col-md-12">
                                                <div class="input-group mb-3">
                                                    <div class="input-group-prepend">
                                                    <span class="input-group-text" id="inputGroup-sizing-default">Judul : </span>
                                                    </div>
                                                    <input type="text" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" name="artikel_judul">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12 col-sm-12 col-md-12">
                                                <textarea  name="artikel_isi">
                                                    
                                                </textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-4 col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <div class="container">

                                        <div class="row mb-2">
                                            <div class="col-lg-12 col-sm-12 col-md-12 d-flex justify-content-start inline">
                                                <input type="date" name="artikel_dibuat">  
                                                </div>  
                                            </div>
                                        </div>

                                        <div class="row mx-auto">
                                            <div class="col-lg-12 col-sm-12 col-md-12 mx-auto d-flex justify-content-center">
                                                <div class="input-group mb-2">
                                                    <div class="input-group-prepend">
                                                        <div class="dropdown">
                                                            <button class="btn btn-info dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            Pilih Kategori Berita 
                                                            </button>
                                                            <div class="dropdown-menu makescroll" aria-labelledby="dropdownMenuButton">
                                                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <a class="dropdown-item" href="#"><input class="" type="checkbox" name="kategori[]" value="<?php echo e($kat2->id); ?>">&nbsp; <?php echo e($kat2->kategori_name); ?></a>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row mx-auto">
                                            <div class="col-lg-12 col-sm-12 col-md-12">
                                                <div class="input-group mb-2">
                                                    <div class="input-group-prepend">
                                                      <span class="input-group-text" id="inputGroupFileAddon01">Gambar Depan</span>
                                                    </div>
                                                    <div class="custom-file">
                                                      <input type="file" class="custom-file-input" id="inputGroupFile01" name="gambar">
                                                      <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row mx-auto">
                                            <div class="col-lg-12 col-sm-12 col-md-12">
                                                <div class="input-group mt-1">
                                                    <div class="input-group-prepend">
                                                      <label class="input-group-text" for="inputGroupSelect01">Status Berita : </label>
                                                    </div>
                                                    <select class="custom-select" id="inputGroupSelect01" name="artikel_status">
                                                      <option selected>Choose...</option>
                                                      <option value="published">Published</option>
                                                      <option value="draft">Draft</option>
                                                      <option value="review">Review</option>
                                                    </select>
                                                  </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="mt-2 col-sm-12 col-md-12 col-lg-12">
                            <button type="submit" class="mt-2 btn btn-info float-right">Posting</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        tinymce.init({
            selector: 'textarea',
            plugins: 'advlist autolink lists link image charmap print preview hr anchor pagebreak',
            toolbar_mode: 'floating',
        });

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fathur/public_html/remake-sultra1news/resources/views/dashboard/tambah-artikel.blade.php ENDPATH**/ ?>