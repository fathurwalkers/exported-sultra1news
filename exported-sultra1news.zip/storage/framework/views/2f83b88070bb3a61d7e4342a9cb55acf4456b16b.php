<?php $__env->startSection('recent-articles'); ?>
<div class="recent-articles mt-2">
    <div class="container">
       <div class="recent-wrapper">
            <!-- section Tittle -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-tittle mb-30">
                        <h3>Recent Articles</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="recent-active dot-style d-flex dot-style">
                        <?php $__currentLoopData = $artikel_paginate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikelpaginate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-recent mb-100">
                                <div class="what-img">
                                    <img src="<?php echo e(asset('post-images')); ?>/<?php echo e($artikelpaginate->artikel_headergambar); ?>" alt="" width="360" height="335">
                                </div>
                                <div class="what-cap">
                                    <?php $__currentLoopData = $artikelpaginate->kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategoripaginate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="color3">
                                            <?php echo e($kategoripaginate->kategori_name); ?>

                                        </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <h4><a href="/show/post/<?php echo e($artikelpaginate->artikel_slug); ?>"><?php echo e($artikelpaginate->artikel_judul); ?></a></h4>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
       </div>
    </div>
</div>           

<div class="pagination-area pb-45 text-center">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="single-wrap d-flex justify-content-center">
                    <nav aria-label="Page navigation example">
                        
                        <?php echo e($artikel_paginate->links()); ?>

                      </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('trending-top'); ?>
    <?php $__currentLoopData = $artikel_trendingtop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikeltop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="trending-top mb-30">
        <div class="trend-top-img">
            <img src="<?php echo e(asset('post-images/')); ?>/<?php echo e($artikeltop->artikel_headergambar); ?>" alt="" width="750" height="400">
            <div class="trend-top-cap">
                <?php $__currentLoopData = $artikeltop->kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategoriname2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span>
                        <?php echo e($kategoriname2->kategori_name); ?>

                    </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <h2><a href="/show/post/<?php echo e($artikeltop->artikel_slug); ?>"><?php echo e(Str::limit($artikeltop->artikel_judul, 45)); ?></a></h2>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('trending-bottom'); ?>
<div class="trending-bottom">
    <div class="row">
        <?php $__currentLoopData = $artikel_random_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikelrandom3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
                <div class="single-bottom mb-35">
                    <div class="trend-bottom-img mb-30">
                        <img src="<?php echo e(asset('post-images/')); ?>/<?php echo e($artikelrandom3->artikel_headergambar); ?>" alt="" width="240" height="160">
                    </div>
                    <div class="trend-bottom-cap">
                        <?php $__currentLoopData = $artikelrandom3->kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategoriname2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="color3">
                                <?php echo e($kategoriname2->kategori_name); ?>

                            </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <h4><a href="/show/post/<?php echo e($artikelrandom3->artikel_slug); ?>"><?php echo e(Str::limit($artikelrandom3->artikel_judul, 40)); ?></a></h4>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('right-content'); ?>
<div class="col-lg-4">
    <?php $iter = [1, 3, 4]
    ?>
    <?php $__currentLoopData = $artikel_5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel_right): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="trand-right-single d-flex">
        <div class="trand-right-img">
            <img src="<?php echo e(asset('post-images/')); ?>/<?php echo e($artikel_right->artikel_headergambar); ?>" alt="" width="120" height="100">
        </div>
        <div class="trand-right-cap">
                
                    <?php $__currentLoopData = $artikel_right->kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategoriname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="color<?php echo e(Arr::random($iter)); ?>">
                            <?php echo e($kategoriname->kategori_name); ?>

                        </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            <h4><a href="/show/post/<?php echo e($artikel_right->artikel_slug); ?>"><?php echo e($artikel_right->artikel_judul); ?></a></h4>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('weekly-one'); ?>
<div class="weekly-news-area pt-50">
    <div class="container">
       <div class="weekly-wrapper">
            <!-- section Tittle -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-tittle mb-30">
                        <h3>Weekly Top News</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="weekly-news-active dot-style d-flex dot-style">
                        <?php $__currentLoopData = $artikelweekly_one; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weeklyone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="weekly-single">
                                <div class="weekly-img">
                                    <img src="<?php echo e(asset('post-images/')); ?>/<?php echo e($weeklyone->artikel_headergambar); ?>" alt="" width="360" height="420">
                                </div>
                                <div class="weekly-caption">
                                    <?php $__currentLoopData = $weeklyone->kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategoriname_weeklyone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="color4">
                                            <?php echo e($kategoriname_weeklyone->kategori_name); ?>

                                        </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <h4><a href="/show/post/<?php echo e($weeklyone->artikel_slug); ?>"><?php echo e($weeklyone->artikel_judul); ?></a></h4>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
       </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('weekly-two'); ?>
<div class="weekly2-news-area  weekly2-pading gray-bg">
    <div class="container">
        <div class="weekly2-wrapper">
            <!-- section Tittle -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-tittle mb-30">
                        <h3>Weekly Top News</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="weekly2-news-active dot-style d-flex dot-style">
                        <?php $__currentLoopData = $artikelweekly_two; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weeklytwo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="weekly2-single">
                                <div class="weekly2-img">
                                    <img src="<?php echo e(asset('post-images/')); ?>/<?php echo e($weeklytwo->artikel_headergambar); ?>" alt="" width="263" height="170">
                                </div>
                                <div class="weekly2-caption">
                                    <?php $__currentLoopData = $weeklytwo->kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategoriname_weeklytwo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="color3">
                                            <?php echo e($kategoriname_weeklytwo->kategori_name); ?>

                                        </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e(date("D, M - Y", strtotime($weeklytwo->artikel_dibuat))); ?></p>
                                    <h4><a href="/show/post/<?php echo e($weeklytwo->artikel_slug); ?>"><?php echo e($weeklytwo->artikel_judul); ?></a></h4>
                                </div>
                            </div> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>       
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fathur/public_html/remake-sultra1news/resources/views/home.blade.php ENDPATH**/ ?>