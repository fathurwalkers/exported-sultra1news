<?php $__env->startSection('main-section'); ?>
<div class="card">
    <div class="card-header bg-dark text-white text-bold">
            Semua Postingan
        <a class="btn btn-success btn-sm float-right" href="<?php echo e(route('tambah-artikel')); ?>" role="button">Tambah Postingan</a>
    </div>
    <div class="card-body">
        <table id="example1" class="table table-bordered table-responsive" style="width:100%">
            <thead class="thead-dark">
            <tr>
                <th>Judul</th>
                <th>Status</th>
                <th>Penulis</th>
                <th>Kategori</th>
                <th>Tanggal Posting</th>
                <th>Kelola</th>
            </tr>
        </thead>
            <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <tr>
                    <td><?php echo e(Str::limit($artikel->artikel_judul, 45, '...')); ?></td>

                    <?php switch($artikel->artikel_status):
                        case ('published'): ?>
                        <td><button class="btn btn-sm btn-success"><?php echo e(strtoupper($artikel->artikel_status)); ?></td>        
                            <?php break; ?>
                        <?php case ('draft'): ?>
                        <td><button class="btn btn-sm btn-danger"><?php echo e(strtoupper($artikel->artikel_status)); ?></td>        
                            <?php break; ?>
                        <?php case ('review'): ?>
                        <td><button class="btn btn-sm btn-info"><?php echo e(strtoupper($artikel->artikel_status)); ?></td>        
                            <?php break; ?>
                    <?php endswitch; ?>

                    <?php if(!$artikel->login->name): ?>
                        <td>Admin</td>
                    <?php else: ?>
                        <td><?php echo e($artikel->login->name); ?></td>                    
                    <?php endif; ?>
                    <td class="mx-auto">
                        <?php $__currentLoopData = $artikel->kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namekategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <a class="btn btn-success btn-sm" href="#" role="button"><?php echo e($namekategori->kategori_name); ?></a>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td><?php echo e(date("D, M - Y", strtotime($artikel->artikel_dibuat))); ?></td>
                    <td class="">
                        <div class="container">
                            <div class="row m-0 p-0">
                                <div class="col-sm-12 col-lg-12 col-md-12 mx-auto text-center">
                                    <a class="btn btn-success btn-sm" href="#" role="button">Lihat</a>
                                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('edit-artikel', $artikel->id)); ?>" role="button">Edit</a>
                                    
                                    <form action="<?php echo e(route('delete-artikel', [$artikel->id])); ?>" class="d-inline"
                                        onsubmit="return confirm('Klik OK, jika ingin menghapus data?<?php echo e($artikel->id); ?>')" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <input type="submit" class="btn btn-danger btn-sm" value="Delete <?php echo e($artikel->id); ?>">
                                    </form>
                                    

                                    

                                    
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $('#example1').DataTable();
        } );
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fathur/public_html/remake-sultra1news/resources/views/dashboard/daftar-artikel.blade.php ENDPATH**/ ?>