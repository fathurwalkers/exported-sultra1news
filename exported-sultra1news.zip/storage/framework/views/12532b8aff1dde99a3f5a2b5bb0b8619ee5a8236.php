<?php $__env->startSection('main-section'); ?>
    <?php if(session('gagal_beralih')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('gagal_beralih')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fathur/public_html/remake-sultra1news/resources/views/dashboard.blade.php ENDPATH**/ ?>